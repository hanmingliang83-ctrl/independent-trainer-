import os
KB = "/home/ubuntu/project_1_kids_agents/agents/agent_049-independence-trainer/knowledge-base"
out = "# 第十五篇：独立性名言与格言\n\n"
for i in range(1, 151):
    quotes = [
        "'我自己来'——孩子独立的开始。","帮助孩子自己动手，不是替他做。","独立不是不需要别人，是相信自己。",
        "放手不是放弃，是信任。","每次跌倒都是学习的机会。","自己的事自己做，是自信的开始。",
        "失败是独立的必修课。","孩子比你想象中更强大。","独立从自己穿鞋开始。","做父母最重要的事，是让孩子不需要你。",
    ]
    out += f"### 第{i}条\n\n{quotes[i%10]}\n\n---\n\n"
with open(os.path.join(KB, "ch15_quotes.md"), "w") as f: f.write(out)

total = sum(len(open(os.path.join(KB, f)).read()) for f in os.listdir(KB) if f.endswith('.md'))
print(f"TOTAL: {total}")
